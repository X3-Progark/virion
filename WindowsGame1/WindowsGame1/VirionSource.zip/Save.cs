﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Virion
{
    public class Save
    {
        public Player[] players;
        public int level;
    }
}
